#include "SampleKeyEventHandler.h"

#include "debug.h"
#include "Game.h"

#include "Mario.h"
#include "Simon.h"

extern CMario* mario;
extern CSimon* simon;

void CSampleKeyHandler::OnKeyDown(int KeyCode)
{
	DebugOut(L"[INFO] KeyDown: %d\n", KeyCode);
	switch (KeyCode)
	{
	case DIK_S:
		//mario->SetState(MARIO_STATE_JUMP);
		simon->SetState(SIMON_STATE_JUMP);
		break;
	}
}

void CSampleKeyHandler::OnKeyUp(int KeyCode)
{
	DebugOut(L"[INFO] KeyUp: %d\n", KeyCode);
	switch (KeyCode)
	{
	case DIK_S:
		//mario->SetState(MARIO_STATE_RELEASE_JUMP);
		simon->SetState(SIMON_STATE_RELEASE_JUMP);
		break;
	case DIK_DOWN:
		//mario->SetState(MARIO_STATE_SIT_RELEASE);
		simon->SetState(SIMON_STATE_SIT_RELEASE);
		break;
	}
}

void CSampleKeyHandler::KeyState(BYTE *states)
{
	CGame* game = CGame::GetInstance();

	if (game->IsKeyDown(DIK_RIGHT))
	{
		/*if (game->IsKeyDown(DIK_A))
			mario->SetState(MARIO_STATE_RUNNING_RIGHT);
		else
		{
			mario->SetState(MARIO_STATE_WALKING_RIGHT);
			simon->SetState(SIMON_STATE_WALKING_RIGHT);
		}*/
		simon->SetState(SIMON_STATE_WALKING_RIGHT);

		if (game->IsKeyDown(DIK_UP))
		{
			//mario->SetState(MARIO_STATE_JUMP);
			simon->SetState(SIMON_STATE_JUMP);
		}
	}
	else if (game->IsKeyDown(DIK_LEFT))
	{
		/*if (game->IsKeyDown(DIK_A))
			mario->SetState(MARIO_STATE_RUNNING_LEFT);
		else
		{
			mario->SetState(MARIO_STATE_WALKING_LEFT);
			simon->SetState(SIMON_STATE_WALKING_LEFT);
		}*/
		simon->SetState(SIMON_STATE_WALKING_LEFT);

		if (game->IsKeyDown(DIK_UP))
		{
			//mario->SetState(MARIO_STATE_JUMP);
			simon->SetState(SIMON_STATE_JUMP);
		}
	}
	else if (game->IsKeyDown(DIK_UP))
	{
		//mario->SetState(MARIO_STATE_JUMP);
		simon->SetState(SIMON_STATE_JUMP);

		if (game->IsKeyDown(DIK_RIGHT))
		{
			/*if (game->IsKeyDown(DIK_A))
				mario->SetState(MARIO_STATE_RUNNING_RIGHT);
			else
			{
				mario->SetState(MARIO_STATE_WALKING_RIGHT);
				simon->SetState(SIMON_STATE_WALKING_RIGHT);
			}*/
			simon->SetState(SIMON_STATE_WALKING_RIGHT);
		}
		else if (game->IsKeyDown(DIK_LEFT))
		{
			/*if (game->IsKeyDown(DIK_A))
				mario->SetState(MARIO_STATE_RUNNING_LEFT);
			else
			{
				mario->SetState(MARIO_STATE_WALKING_LEFT);
				simon->SetState(SIMON_STATE_WALKING_LEFT);
			}*/
			simon->SetState(SIMON_STATE_WALKING_LEFT);
		}
	}
	else
	{
		//mario->SetState(MARIO_STATE_IDLE);
		simon->SetState(SIMON_STATE_IDLE);
	}

	// Sitting state has higher priority 
	if (game->IsKeyDown(DIK_DOWN))
	{
		//mario->SetState(MARIO_STATE_SIT);
		simon->SetState(SIMON_STATE_SIT);
	}

}